package com.testcases;

import com.base.BasePage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/*
* WRITE BY : 陈若繁
*/

public class Case extends BasePage{
    //成功登录
    public void loginSuccess(String username,String password) throws InterruptedException {
		driver.findElementByXPath("//*[@text='我']").click();
		driver.findElementByXPath("//*[@text='点击登陆']").click();
		driver.findElementById("neet.com.youjidemo:id/et_userPhone").sendKeys(username);
		driver.findElement(By.className("android.widget.RelativeLayout")).sendKeys(password);
		driver.findElementById("neet.com.youjidemo:id/btn_login").click();
	}
	@Test
    public void test1(){
        loginSuccess("18031712521","123123");
    }

    //登录的用户名不存在
    public void loginNone(String username,String password) throws InterruptedException {
        driver.findElementByXPath("//*[@text='我']").click();
        driver.findElementByXPath("//*[@text='点击登陆']").click();
        driver.findElementById("neet.com.youjidemo:id/et_userPhone").sendKeys(username);
        driver.findElement(By.className("android.widget.RelativeLayout")).sendKeys(password);
        driver.findElementById("neet.com.youjidemo:id/btn_login").click();
    }
    @Test
    public void test2(){
        loginNone("13331712521","123456");
    }

    //登录的用户密码输入错误
	public void loginFault(String username,String password) throws InterruptedException {
		driver.findElementByXPath("//*[@text='我']").click();
		driver.findElementByXPath("//*[@text='点击登陆']").click();
		driver.findElementById("neet.com.youjidemo:id/et_userPhone").sendKeys(username);
        driver.findElement(By.className("android.widget.RelativeLayout")).sendKeys(password);
		driver.findElementById("neet.com.youjidemo:id/btn_login").click();
	}
	@Test
    public void test3(){
        loginFault("18031712521","000000");
    }

    //新用户修改个人信息(个人信息中无前提信息)
	public void newEditPersonalCenter(String sentence,String name) throws InterruptedException {
        driver.findElementByXPath("//*[@text='我']").click();
        driver.findElementByXPath("//*[@text='个人中心']").click();
        driver.findElementByXPath("//*[@text='编辑资料']").click();
        driver.findElementById("neet.com.youjidemo:id/pde_et_introduction").sendKeys(sentence);
        driver.findElementById("neet.com.youjidemo:id/pde_et_name").sendKeys(name);
        driver.findElementById(" neet.com.youjidemo:id/pde_tv_sex").click();
        driver.findElementByXPath("//*[@text='女']").click();
        driver.findElementByXPath("//*[@text='完成']").click();
	}
    @Test
    public void test4(){
        newEditPersonalCenter("我好哇塞","陈若繁");
    }

    //老用户修改个人信息（个人信息中已经存在信息）
    public void editPersonalCenter(String sentence,String name) throws InterruptedException {
        driver.findElementByXPath("//*[@text='我']").click();
        driver.findElementByXPath("//*[@text='个人中心']").click();
        driver.findElementByXPath("//*[@text='编辑资料']").click();
        driver.findElementById("neet.com.youjidemo:id/pde_et_introduction").clear();
        driver.findElementById("neet.com.youjidemo:id/pde_et_introduction").sendKeys(sentence);
        driver.findElementById("neet.com.youjidemo:id/pde_et_name").clear();
        driver.findElementById("neet.com.youjidemo:id/pde_et_name").sendKeys(name);
        driver.findElementById(" neet.com.youjidemo:id/pde_tv_sex").click();
        driver.findElementByXPath("//*[@text='女']").click();
        driver.findElementByXPath("//*[@text='完成']").click();
    }
    @Test
    public void test5(){
        editPersonalCenter("一直在学习的路上","陈陈陈");
    }

    //查看收藏列表
	public void checkCollectList() throws InterruptedException {
		driver.findElementByXPath("//*[@text='我']").click();
		driver.findElementByName("收藏").click(); 
	}
    @Test
    public void test6(){
        checkCollectList();
    }

    //查看@我的全部信息
	public void checkAt() throws InterruptedException {
        driver.findElementByName("消息").click();
        driver.findElementByName("消息").click();
        driver.findElementByName("@的消息").click();
        driver.findElementById("neet.com.youjidemo:id/ib_collection").click();
	}
    @Test
    public void test7(){
        checkAt();
    }

    //查看全部评论我的信息
	public void checkComm() throws InterruptedException {
        driver.findElementByName("消息").click();
        driver.findElementByName("消息").click();
        driver.findElementByName("评论").click();
	}
    @Test
    public void test8(){
        checkComm();
    }

    //查看全部点赞/收藏的信息
	public void checkZan(String title) throws InterruptedException {
        driver.findElementByName("消息").click();
        driver.findElementByName("消息").click();
        driver.findElementByName("点赞/收藏").click();
        driver.findElementByName(title).click();
        driver.findElementByName("点赞/收藏").click();
	}
    @Test
    public void test9(){
        checkZan();
    }

    //在广场评论帖子
	public void comm(String comment) throws InterruptedException {
        driver.findElementByXPath("//*[@text='社区']").click();
        driver.findElementById("neet.com.youjidemo:id/image_btn_food").click();
        driver.findElementByXPath("//*[@text='广场']").click();
        driver.findElementById("neet.com.youjidemo:id/iv_contentimage").click();
        driver.findElementByXPath("//*[@text='点击发表你的评论']").click();
        driver.findElementById("neet.com.youjidemo:id/comment_content").sendKeys(comment);
        driver.findElementById(" neet.com.youjidemo:id/comment_send").click();
    }
    @Test
    public void test10(){
        comm("This is a good idea!");
    }

    //在推荐页面进行评论
    public void maincomm(String comment) throws InterruptedException {
    	driver.findElementByXPath("//*[@text='首页']").click();
    	driver.findElementByXPath("//*[@text='游玩']").click();
    	driver.findElementById("neet.com.youjidemo:id/iv_contentimage").click();
        driver.findElementById("neet.com.youjidemo:id/comment_content").sendKeys(comment);
        driver.findElementById(" neet.com.youjidemo:id/comment_send").click();
    }
    @Test
    public void test11(){
        comm("I agree with you!");
    }

    //关注用户
    public void follow() throws InterruptedException {
    	driver.findElementByXPath("//*[@text='首页']").click();
    	driver.findElementByXPath("//*[@text='逛街']").click();
        driver.findElementById("neet.com.youjidemo:id/btn_care").click();
    }
    @Test
    public void test12(){
        follow();
    }

    //添加帖子
    public void addcomment(String passage) throws InterruptedException {
        driver.findElementById("neet.com.youjidemo:id/tab_icon").click();
        driver.findElementById("neet.com.youjidemo:id/et_share_passage").clear();
        driver.findElementById("neet.com.youjidemo:id/et_share_passage").sendKeys(passage);
        driver.findElementByName("点击增加图片或视频").click();
        driver.findElement(By.className("android.widget.RelativeLayout")).click();
        driver.findElementById("com.google.android.apps.photos:id/image").click();
        driver.findElementByName("上传").click();
    }
    @Test 
    public void test13(){
        addcomment("美好的一天从早起开始");
    }

    //查看足迹
    public void checkHistory() throws InterruptedException {
        driver.findElementByXPath("//*[@text='我']").click();
        driver.findElementByName("足迹").click(); 
    }
    @Test
    public void test14(){
        checkHistory();
    }

    //后退按钮
    public void comeback() throws InterruptedException {
        driver.findElementByName("我").click();
        driver.findElementByName("个人中心").click();
        driver.findElementById("neet.com.youjidemo:id/btn_cancel").click();
    }
    @Test
    public void test15(){
        comeback();
    }

    //查看推荐中的游玩
    public void checkplay() throws InterruptedException {
        driver.findElementByName("首页").click();
        driver.findElementByName("游玩").click();
    }
    @Test
    public void test16(){
        checkplay();
    }

    //查看推荐中的摄影
    public void checkphoto() throws InterruptedException {
        driver.findElementByName("首页").click();
        driver.findElementByName("摄影").click();
    }
    @Test
    public void test17(){
        checkphoto();
    }

    //查看推荐中的滑冰
    public void checkskate() throws InterruptedException {
        driver.findElementByName("首页").click();
        driver.findElementByName("滑冰").click();
    }
    @Test
    public void test18(){
        checkskate();
    }

    //查看推荐中的美食
    public void checkfood() throws InterruptedException {
        driver.findElementByName("首页").click();
        driver.findElementByName("美食").click();
    }
    @Test
    public void test19(){
        checkfood();
    }

    //查看推荐中的美食
    public void checkfood() throws InterruptedException {
        driver.findElementByName("首页").click();
        driver.findElementByName("美食").click();
    }
    @Test
    public void test19(){
        checkfood();
    }

    //查看推荐中的逛街
    public void checkbuy() throws InterruptedException {
        driver.findElementByName("首页").click();
        driver.findElementByName("逛街").click();
    }
    @Test
    public void test20(){
        checkbuy();
    }

}
